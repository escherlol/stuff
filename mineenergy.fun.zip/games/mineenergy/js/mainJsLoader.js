'use strict';
(function () {
    const $screen = document.getElementById("load-main-js-screen");
    const $progressBar = document.getElementById("load-main-js-progress-bar");
    const $progress = document.getElementById("load-main-js-progress");
    const $player = document.getElementById("player");
    let mainJsScript;
    let mainJsLoaded = false;
    let mainJsExecuted = false;
    let windowLoaded = false;
    const PROBABLY_MAX_JS_LENGTH = 3786712;
    const playerSkins = ['steve'];
    const loadedPlayerSkins = [];
    let interval;

    const req = new XMLHttpRequest();
    req.addEventListener("progress", onProgress, false);
    req.addEventListener("load", onLoad, false);
    req.addEventListener("error", onError, false);

    if (window.addEventListener) {
        window.addEventListener('load', onWindowLoad);
    } else {
        window.attachEvent('onload', onWindowLoad);
    }

    $progressBar.classList.add("show");
    loadPlayerSkins();
    startAnimation();

    // To comment line below when upload on production
    if (typeof window.MAIN_JS_SRC === 'undefined') {
        window.MAIN_JS_SRC = `games/mineenergy/js/v0.001/main.js`
    }

    document.addEventListener("DOMContentLoaded", function () {
        req.open("GET", MAIN_JS_SRC);
        req.send();
    });

    function onWindowLoad() {
        windowLoaded = true;
    }

    function loadPlayerSkins() {
        for (let i = 0; i < playerSkins.length; i++) {
            loadImage(`/games/mineenergy/images/textures/players/${playerSkins[i]}.png`)
                .then(function ($img) {
                    loadedPlayerSkins.push($img)
                });
        }
    }

    function startAnimation() {
        interval = setInterval(function () {
            cleanElement($player);
            var $img = getRandomFromArray(loadedPlayerSkins);
            if ($img) {
                $player.appendChild($img);
            }
        }, 200);
    }

    function onProgress(event) {
        let percentComplete;
        if (event.lengthComputable) {
            percentComplete = event.loaded / event.total;
        } else {
            percentComplete = event.loaded / PROBABLY_MAX_JS_LENGTH;
        }
        if ($progress) {
            $progress.style.width = `${percentComplete * 100}%`;
        }
    }

    function onLoad(event) {
        if (req.status === 404) {
            throw new Error('404');
            return;
        }

        mainJsLoaded = true;
        mainJsScript = document.createElement("script");
        mainJsScript.innerHTML = event.target.responseText;
        executeMainJS();
        hideLoadMainJsScreen(1000);
    }

    function onError(event) {
        console.log(event)
    }

    function executeMainJS() {
        if (!mainJsScript || mainJsExecuted) {
            return;
        }

        mainJsExecuted = true;
        document.documentElement.appendChild(mainJsScript);
        if (windowLoaded) {
            window.GAME.window.events.emit("windowLoaded");
        }
    }

    function hideLoadMainJsScreen(timeout) {
        if (timeout) {
            setTimeout(hideLoadMainJsScreenForce, timeout);
        } else {
            hideLoadMainJsScreenForce();
        }
    }

    function hideLoadMainJsScreenForce() {
        if (interval) {
            clearInterval(interval);
            interval = null;
        }
        if ($screen) {
            $screen.classList.add("hide");
        }
        setTimeout(function () {
            if ($screen) {
                $screen.remove();
            }
        }, 500);
    }

    function getUrlParameter(parameterName) {
        let result = null;
        let tmp = [];
        const items = location.search.substr(1).split("&");
        for (let index = 0; index < items.length; index++) {
            tmp = items[index].split("=");
            if (tmp[0] === parameterName) {
                result = decodeURIComponent(tmp[1]);
            }
        }
        return result;
    }

    function getRandomFromArray(array) {
        return array[getRandomInt(0, array.length - 1)];
    }

    function getRandomInt(min, max) {
        if (min === undefined) {
            min = 0;
        }
        if (max === undefined) {
            max = 1;
        }
        max++;
        return Math.floor(getRandomFloat(min, max));
    }

    function getRandomFloat(min, max) {
        if (min === undefined) {
            min = 0;
        }
        if (max === undefined) {
            max = 1;
        }
        max--;
        return Math.random() * (max - min + 1) + min;
    }

    function loadImage(url) {
        return new Promise(function (resolve, reject) {
            const $img = document.createElement('img');
            $img.addEventListener('load', function () {
                // $img.remove();
                resolve($img);
            });
            $img.addEventListener('error', function () {
                $img.remove();
                reject();
            });
            $img.src = url;
        })
    }

    function cleanElement(element) {
        while (element.firstChild) {
            element.removeChild(element.firstChild);
        }
    }
})();
